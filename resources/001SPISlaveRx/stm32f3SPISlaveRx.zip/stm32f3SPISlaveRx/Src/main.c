#include <stdint.h>

uint32_t GPIOA_BASEADDR = 0x48000000U;
uint32_t GPIOE_BASEADDR = 0x48001000U;
uint32_t RCC_BASEADDR = 0x40021000U;
uint32_t SPI1_BASEADDR = 0x40013000U;

// Simple imprecise delay method.
void __attribute__( ( optimize( "O0" ) ) )
delay_cycles( uint32_t cyc ) {
  for ( uint32_t d_i = 0; d_i < cyc; ++d_i ) { asm( "NOP" ); }
}

void SPI1_GPIOInit(void) {
	uint32_t *pRCCAHBENR = (uint32_t*)(RCC_BASEADDR+0x14);
	uint32_t *pGPIOA = (uint32_t*)GPIOA_BASEADDR;

	//Enable GPIOA peripheral clock
	*pRCCAHBENR |= (1 << 17);

	//Configure PA7 (MOSI)
	*pGPIOA |= (0x3 << 14); //Set mode to Alternate function
	*((uint32_t*)(GPIOA_BASEADDR+0x20)) |= (0x5 << 28); //Set AFR7 to AF5
	//Pin set to Push pull, with no PUPD by default

	//Configure PA5 (SCLK)
	*pGPIOA |= (0x3 << 10); //Set mode to Alternate function
	*((uint32_t*)(GPIOA_BASEADDR+0x20)) |= (0x5 << 20); //Set AFR5 to AF5
	//Pin set to Push pull, with no PUPD by default

	//Configure PA6 (MISO)
	*pGPIOA |= (0x3 << 12); //Set mode to Alternate function
	*((uint32_t*)(GPIOA_BASEADDR+0x20)) |= (0x5 << 24); //Set AFR6 to AF5
	//Pin set to Push pull, with no PUPD by default

	//Configure PA4 (NSS)
	*pGPIOA |= (0x3 << 8); //Set mode to Alternate function
	*((uint32_t*)(GPIOA_BASEADDR+0x20)) |= (0x5 << 16); //Set AFR4 to AF5
	//Pin set to Push pull, with no PUPD by default
}


void SPI1_Init(void) {
	uint32_t *pRCCAPB2ENR = (uint32_t*)(RCC_BASEADDR+0x18);
	uint32_t *pSPI1 = (uint32_t*)SPI1_BASEADDR;

	//Enable SPI1 peripheral clock
	*pRCCAPB2ENR |= (1 << 12);

	//Configure SPI1 peripheral
	*pSPI1 |= (1 << 10); //Enable Receive only mode
	*pSPI1 |= (1 << 1); //Set CPOL to high
	*pSPI1 |= (0x2 << 3); //Set Baud Rate to 16 / 8 = 2MHz
	//Rest of default settings should be fine
	//Slave config, CPOL = 0, CPHA = 0, SSM = Disabled

	//Enable the SPI1 peripheral
	*pSPI1 |= (1 << 6); //Enable SPE bit
}

int main(void)
{
	//Initialize Addresses
	uint32_t *pGPIOE = (uint32_t*)GPIOE_BASEADDR;
	uint32_t *pRCCAHBENR = (uint32_t*)(RCC_BASEADDR+0x14);

	//This function is used to initialize the GPIO pins to behave as SPI2 pins
	SPI1_GPIOInit();

	//Start receiving on SPI1 peripheral
	SPI1_Init();

	// Configure the LEDs
	*pRCCAHBENR |= (1<<21);	//Configure Port E for Clock using RCC
	*pGPIOE |= 0x55550000;	//Configure Port E pin 8-15 for output

	//Blink LEDs
	uint32_t delay = 500000;
	while(1) {
		//Turn on LEDs
		*((uint32_t*)(GPIOE_BASEADDR+0x14)) |= 0x0000FF00;	//Pin 8-15 ODR Output Data Register set to 1
		delay_cycles(delay);
		//Turn off LEDs
		*((uint32_t*)(GPIOE_BASEADDR+0x14)) &= ~(0x0000FF00);	//Pin 8-15 ODR Output Data Register set to 0
		delay_cycles(delay);
	}
}
